// import 'react-native-url-polyfill/auto';
// import { createClient } from '@supabase/supabase-js';

// const SUPABASE_URL = "https://raoohjclgxiuushhdwvv.supabase.co";
// const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhb29oamNsZ3hpdXVzaGhkd3Z2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc0MzkzMTEsImV4cCI6MjA3MzAxNTMxMX0.LgK_EzTdLWn9ELp-riXnyWV0MVI3pLMCtTPss-s2aKc";

// export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);





import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = "https://raoohjclgxiuushhdwvv.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhb29oamNsZ3hpdXVzaGhkd3Z2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc0MzkzMTEsImV4cCI6MjA3MzAxNTMxMX0.LgK_EzTdLWn9ELp-riXnyWV0MVI3pLMCtTPss-s2aKc";

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
