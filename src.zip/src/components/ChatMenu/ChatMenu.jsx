// ChatMenu.jsx
import React, { useEffect, useState, useRef } from "react";
import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";
// import { supabase } from "../config/supabaseClient";
import { supabase} from '../../firebase/supabaseClient';
import { auth } from "../config/firebase"; // adjust if you use firebase auth
import { FiPhone, FiVideo, FiMoreVertical, FiTrash2, FiBan } from "react-icons/fi";
// import "./ChatMenu.css";
import '../../components/ChatMenu.css';

const ChatMenu = ({ chatName, chatId, isActive, email, avatar, about, isactivestatus }) => {
  const navigate = useNavigate();
  const currentEmail = auth?.currentUser?.email;
  const [isBlocked, setIsBlocked] = useState(false);
  const [fcmToken, setFcmToken] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [selfFcmToken, setSelfFcmToken] = useState("");
  const [selfAccessToken, setSelfAccessToken] = useState("");
  const [isChatDisabled, setIsChatDisabled] = useState(false);
  const channelRef = useRef(null);
  const [menuOpen, setMenuOpen] = useState(false);

  // fetch partner tokens and listen to updates
  useEffect(() => {
    if (!email) return;
    let channel;

    const fetchUserData = async () => {
      try {
        const { data, error } = await supabase
          .from("users")
          .select("isoncallstatus, fcmToken, accessToken, avatar")
          .eq("email", email)
          .single();

        if (!error && data) {
          setFcmToken(data.fcmToken || "");
          setAccessToken(data.accessToken || "");
        }
      } catch (err) {
        console.error("fetchUserData error:", err);
      }
    };

    const subscribe = () => {
      channel = supabase
        .channel(`users-changes-${email}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "users",
            filter: `email=eq.${email}`,
          },
          (payload) => {
            const newData = payload.new || {};
            setFcmToken(newData.fcmToken || "");
            setAccessToken(newData.accessToken || "");
          }
        )
        .subscribe();

      channelRef.current = channel;
    };

    fetchUserData();
    subscribe();

    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [email]);

  // fetch self tokens
  useEffect(() => {
    let ch;
    const fetchSelf = async () => {
      try {
        if (!currentEmail) return;
        const { data, error } = await supabase
          .from("users")
          .select("fcmToken, accessToken, avatar")
          .eq("email", currentEmail)
          .single();

        if (!error && data) {
          setSelfFcmToken(data.fcmToken || "");
          setSelfAccessToken(data.accessToken || "");
        }

        ch = supabase
          .channel(`users-changes-self-${currentEmail}`)
          .on(
            "postgres_changes",
            {
              event: "UPDATE",
              schema: "public",
              table: "users",
              filter: `email=eq.${currentEmail}`,
            },
            (payload) => {
              const newData = payload.new || {};
              setSelfFcmToken(newData.fcmToken || "");
              setSelfAccessToken(newData.accessToken || "");
            }
          )
          .subscribe();
      } catch (err) {
        console.error("fetchSelf error:", err);
      }
    };

    fetchSelf();

    return () => {
      if (ch) supabase.removeChannel(ch);
    };
  }, [currentEmail]);

  // block list watchers + initial checks
  useEffect(() => {
    let targetCh, currentCh;
    const init = async () => {
      if (!email || !currentEmail) return;

      // helper to fetch blocked list row
      const fetchBlockedList = async (userEmail) => {
        try {
          const { data } = await supabase.from("blockusers").select("TotalBlockUser").eq("email", userEmail).single();
          return Array.isArray(data?.TotalBlockUser) ? data.TotalBlockUser : [];
        } catch (err) {
          return [];
        }
      };

      const targetBlocked = await fetchBlockedList(email);
      const hasBlockedMe = targetBlocked.some((u) => u.email === currentEmail);

      const myBlocked = await fetchBlockedList(currentEmail);
      const iBlockedHim = myBlocked.some((u) => u.email === email);

      setIsChatDisabled(hasBlockedMe || iBlockedHim);
      setIsBlocked(iBlockedHim);
    };

    init();

    // subscribe to changes on blockusers rows for both users
    if (email && currentEmail) {
      targetCh = supabase
        .channel(`blockusers-target-${email}`)
        .on(
          "postgres_changes",
          { event: "UPDATE", schema: "public", table: "blockusers", filter: `email=eq.${email}` },
          (payload) => {
            const blockedList = Array.isArray(payload.new?.TotalBlockUser) ? payload.new.TotalBlockUser : [];
            const hasBlockedMe = blockedList.some((u) => u.email === currentEmail);
            setIsChatDisabled(hasBlockedMe);
          }
        )
        .subscribe();

      currentCh = supabase
        .channel(`blockusers-current-${currentEmail}`)
        .on(
          "postgres_changes",
          { event: "UPDATE", schema: "public", table: "blockusers", filter: `email=eq.${currentEmail}` },
          (payload) => {
            const blockedList = Array.isArray(payload.new?.TotalBlockUser) ? payload.new.TotalBlockUser : [];
            const iBlockedHim = blockedList.some((u) => u.email === email);
            setIsChatDisabled(iBlockedHim);
            setIsBlocked(iBlockedHim);
          }
        )
        .subscribe();
    }

    return () => {
      if (targetCh) supabase.removeChannel(targetCh);
      if (currentCh) supabase.removeChannel(currentCh);
    };
  }, [email, currentEmail]);

  // helpers to manage block
  const checkIfBlocked = async () => {
    try {
      const userEmail = currentEmail;
      if (!userEmail || !email) return;
      const { data } = await supabase.from("blockusers").select("TotalBlockUser").eq("email", userEmail).single();
      const blockedList = Array.isArray(data?.TotalBlockUser) ? data.TotalBlockUser : [];
      setIsBlocked(blockedList.some((u) => u.email === email));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    checkIfBlocked();
  }, [email]);

  const handleBlockToggle = async () => {
    try {
      const userEmail = currentEmail;
      if (!userEmail || !email) return;

      const { data } = await supabase
        .from("blockusers")
        .select("TotalBlockUser")
        .eq("email", userEmail)
        .single();

      let currentList = Array.isArray(data?.TotalBlockUser) ? data.TotalBlockUser : [];

      let updatedList;
      if (isBlocked) {
        updatedList = currentList.filter((u) => u.email !== email);
      } else {
        updatedList = [...currentList, { isblock: true, email }];
      }

      const { error } = await supabase.from("blockusers").upsert({
        email: userEmail,
        TotalBlockUser: updatedList,
      });

      if (error) throw error;
      const newBlocked = !isBlocked;
      setIsBlocked(newBlocked);
      setIsChatDisabled(newBlocked);
      alert(`${newBlocked ? "Blocked" : "Unblocked"} ${email}`);
    } catch (err) {
      console.error("handleBlockToggle error:", err);
      alert("Failed to update block status");
    }
  };

  // Deletions
  const handleDeleteChatForBoth = async () => {
    const ok = window.confirm("Delete this chat for both users? This will permanently delete the chat.");
    if (!ok) return;
    try {
      const userEmail = currentEmail;
      const peerEmail = email;
      if (!userEmail || !peerEmail) throw new Error("Missing emails");

      // find chat
      const { data: chatData, error: chatError } = await supabase
        .from("chats")
        .select("id, participants")
        .contains("participants", [userEmail, peerEmail])
        .single();

      if (chatError || !chatData) throw new Error("Chat not found");

      const toDeleteId = chatData.id;
      const { error: deleteChatError } = await supabase.from("chats").delete().eq("id", toDeleteId);
      if (deleteChatError) throw deleteChatError;

      await supabase.from("deletedchats").delete().eq("chat_id", toDeleteId);

      navigate("/chats");
    } catch (err) {
      console.error(err);
      alert("Error deleting chat: " + (err.message || err));
    }
  };

  const handleDeleteChatEveryOne = async () => {
    const ok = window.confirm("Delete this chat (all messages)? This will permanently remove messages and the chat.");
    if (!ok) return;
    try {
      if (!chatId) throw new Error("chatId missing");
      const { error: deleteMessagesError } = await supabase.from("chat_messages").delete().eq("chat_id", chatId);
      if (deleteMessagesError) throw deleteMessagesError;

      const { error: deleteChatError } = await supabase.from("chats").delete().eq("id", chatId);
      if (deleteChatError) throw deleteChatError;

      navigate("/chats");
    } catch (err) {
      console.error(err);
      alert("Delete chat failed: " + (err.message || err));
    }
  };

  const handleDeleteChat = async () => {
    const ok = window.confirm("Delete chat for me? This will remove it from your view only.");
    if (!ok) return;
    try {
      const userEmail = currentEmail;
      if (!userEmail || !chatId) throw new Error("Missing data");

      const { error } = await supabase.from("deletedchats").upsert(
        {
          user_email: userEmail,
          chat_id: chatId,
          deleted_at: new Date().toISOString(),
        },
        { onConflict: "user_email,chat_id" }
      );

      if (error) throw error;
      alert("Deleted from your view");
    } catch (err) {
      console.error(err);
      alert("Failed to delete: " + (err.message || err));
    }
  };

  // call initiation (just navigates to call page with params)
  const initiateCall = async (isVideo) => {
    try {
      // check busy state quickly (simplified)
      const { data: currentUser } = await supabase
        .from("users")
        .select("isoncallstatus, updatedat")
        .eq("email", currentEmail)
        .single();

      const { data: peerUser } = await supabase
        .from("users")
        .select("isoncallstatus, updatedat")
        .eq("email", email)
        .single();

      // basic stale detection
      const stale = (u) => {
        if (!u?.updatedat) return true;
        const diff = (new Date() - new Date(u.updatedat)) / (1000 * 60);
        return diff > 2;
      };

      const isCurrentBusy = currentUser?.isoncallstatus && !stale(currentUser);
      const isPeerBusy = peerUser?.isoncallstatus && !stale(peerUser);

      if (isCurrentBusy || isPeerBusy) {
        alert("User busy or on call");
        return;
      }

      // navigate to call page (you can implement call screen)
      navigate("/call", {
        state: {
          roomId: currentEmail,
          peerEmail: email,
          fcmToken,
          accessToken,
          selfFcmToken,
          selfAccessToken,
          isVideoCall: isVideo,
          isCaller: true,
        },
      });
    } catch (err) {
      console.error("initiateCall error:", err);
      alert("Call initiation failed");
    }
  };

  return (
    <div className="chat-menu-row">
      <button
        className="icon-btn"
        title="Audio Call"
        onClick={() => {
          if (isChatDisabled) {
            alert("Blocked — you can't call this user.");
          } else {
            initiateCall(false);
          }
        }}
      >
        <FiPhone />
      </button>

      <button
        className="icon-btn"
        title="Video Call"
        onClick={() => {
          if (isChatDisabled) {
            alert("Blocked — you can't video call this user.");
          } else {
            initiateCall(true);
          }
        }}
      >
        <FiVideo />
      </button>

      <div className="menu-root">
        <button className="icon-btn" onClick={() => setMenuOpen((v) => !v)} aria-expanded={menuOpen} title="Menu">
          <FiMoreVertical />
        </button>

        {menuOpen && (
          <div className="menu-dropdown" onMouseLeave={() => setMenuOpen(false)}>
            <button className="menu-item" onClick={handleDeleteChatForBoth}>
              <FiTrash2 /> Delete Chat for Both
            </button>

            <button className="menu-item" onClick={handleDeleteChatEveryOne}>
              <FiTrash2 /> Delete Chat & Messages
            </button>

            <button className="menu-item" onClick={handleDeleteChat}>
              <FiTrash2 /> Delete for Me
            </button>

            <button className="menu-item" onClick={handleBlockToggle}>
              <FiBan /> {isBlocked ? "Unblock User" : "Block User"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

ChatMenu.propTypes = {
  chatName: PropTypes.string.isRequired,
  chatId: PropTypes.string.isRequired,
  email: PropTypes.string,
};

export default ChatMenu;
