// import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
// import './Chat.css';
// import PropTypes from 'prop-types';
// import { IoIosSend, IoIosImages, IoIosGift, IoIosArrowBack, IoIosCall, IoIosVideocam, IoIosClose, IoIosPlay, IoIosPause } from 'react-icons/io';
// import { MdDiamond, MdLocalOffer } from 'react-icons/md';
// import { FaCoins } from 'react-icons/fa';
// import { v4 as uuidv4 } from 'uuid';
// import { doc, updateDoc } from 'firebase/firestore';
// import { db } from '../config/firebase';
// import { ref, getStorage, getDownloadURL, uploadBytesResumable } from 'firebase/storage';
// import { auth } from '../config/firebase';
// import { useNavigate, useLocation } from 'react-router-dom';
// import usePaidStickers from "../screens/PaidStickers";
// import useActiveStatus from './StatusUpdate';
// import { setTypingStatus } from "./SetTypingStatus";
// import DropDownPicker from "react-dropdown-picker";
// import { supabase } from "../config/supabaseClient";

// const Chat = () => {
//   const navigate = useNavigate();
//   const location = useLocation();
//   const route = { params: location.state || {} };
  
//   const [messages, setMessages] = useState([]);
//   const [uploading, setUploading] = useState(false);
//   const [modal, setModal] = useState(false);
//   const [inputText, setInputText] = useState('');
//   const flatListRef = useRef(null);
//   const [showStickerPicker, setShowStickerPicker] = useState(false);
//   const { giftImages, loading } = usePaidStickers();
//   const [pageIndex, setPageIndex] = useState(0);
//   const [isOnline, setIsOnline] = useState(false);
//   const [displayCallAlert, setdisplayCallAlert] = useState(false);
//   const typingTimeoutRef = useRef(null);
//   const [email, setUserEmailId] = useState('');
//   const [blockedList, setBlockedList] = useState([]);
//   const [IsUserSubscription, setIsUserSubscription] = useState([]);
//   const currentEmail = auth?.currentUser?.email;
//   const [isChatDisabled, setIsChatDisabled] = useState(false);
//   const [activeCall, setActiveCall] = useState(null);
//   const [showIncomingCall, setShowIncomingCall] = useState(false);
//   const [callerInfo, setCallerInfo] = useState(null);
//   const [isTyping, setIsTyping] = useState(false);
//   const [timeLeft, setTimeLeft] = useState(60 * 60);
//   const [quantity, setQuantity] = useState(1);
//   const [open, setOpen] = useState(false);
//   const [selectedSticker, setSelectedSticker] = useState(null);
//   const [activeTab, setActiveTab] = useState("gold");
//   const [userGold, setUserGold] = useState();
//   const [userDiamond, setUserDiamond] = useState();
//   const [userNewGold, setUserNewGold] = useState();
//   const [giftImageURL, setGiftImageURL] = useState('');
//   const [isTypeGold, setisTypeGold] = useState(true);
//   const [fcmToken, setfcmToken] = useState("");
//   const [accessToken, setaccessToken] = useState("");

//   const filteredGifts = giftImages.filter(item => 
//     activeTab === "diamond" ? item.isTypeDiamond : !item.isTypeDiamond
//   );

//   useEffect(() => {
//     console.log("🛣️ Chat Screen Route:", route);
//     console.log("📋 Route Params in Chat:", route.params);
//   }, [route]);

//   useEffect(() => {
//     const fetchBlocked = async () => {
//       try {
//         const { data, error } = await supabase
//           .from("blockusers")
//           .select("TotalBlockUser")
//           .eq("email", currentEmail)
//           .single();

//         if (error) {
//           console.log("Error fetching blocked list:", error);
//         } else {
//           const blocked = Array.isArray(data?.TotalBlockUser)
//             ? data.TotalBlockUser.filter(u => u.isblock === true)
//             : [];
//           setBlockedList(blocked);
//         }
//       } catch (err) {
//         console.log(err);
//       }
//     };

//     fetchBlocked();
//   }, []);

//   useEffect(() => {
//     const getBlockStatus = (record, targetEmail) => {
//       const blockedList = Array.isArray(record?.TotalBlockUser)
//         ? record.TotalBlockUser
//         : [];
//       return blockedList.some(u => u.email === targetEmail && u.isblock === true);
//     };

//     const channel = supabase
//       .channel("public:blockusers")
//       .on(
//         "postgres_changes",
//         { event: "UPDATE", schema: "public", table: "blockusers" },
//         payload => {
//           const updated = payload.new;

//           if (updated.email === route.params.email) {
//             const hasBlockedMe = getBlockStatus(updated, currentEmail);
//             setIsChatDisabled(hasBlockedMe);
//           }

//           if (updated.email === currentEmail) {
//             const iBlockedHim = getBlockStatus(updated, route.params.email);
//           }
//         }
//       )
//       .subscribe();

//     const fetchInitialStatus = async () => {
//       try {
//         const { data: targetData } = await supabase
//           .from("blockusers")
//           .select("TotalBlockUser")
//           .eq("email", route.params.email)
//           .single();

//         setIsChatDisabled(getBlockStatus(targetData, currentEmail));

//         const { data: currentData } = await supabase
//           .from("blockusers")
//           .select("TotalBlockUser")
//           .eq("email", currentEmail)
//           .single();
//       } catch (error) {
//         console.log(error);
//       }
//     };

//     fetchInitialStatus();

//     return () => {
//       supabase.removeChannel(channel);
//     };
//   }, []);

//   const sendFcmNotification = async (targetToken, title, body, authToken, extraData = {}) => {
//     const url = "https://fcm.googleapis.com/v1/projects/hiddo-3887f/messages:send";

//     const payload = {
//       message: {
//         token: targetToken,
//         notification: { title, body },
//         data: {
//           ...extraData,
//         },
//       },
//     };

//     console.log("Result the payload tooo late chat.jsss:", payload);

//     const response = await fetch(url, {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//         "Authorization": authToken,
//       },
//       body: JSON.stringify(payload),
//     });

//     const data = await response.json();
//     console.log("Result the dataa tooo late:", data);
//   };

//   useEffect(() => {
//     const email = auth.currentUser?.email;
//     if (!email) {
//       console.warn("No current user found!");
//       return;
//     }

//     console.log("Attaching Supabase realtime listener on:", email);

//     const channel = supabase
//       .channel("user-balance-changes")
//       .on(
//         "postgres_changes",
//         { event: "UPDATE", schema: "public", table: "users", filter: `email=eq.${email}` },
//         (payload) => {
//           console.log("📡 User balance change detected:", payload);
//           const newUser = payload.new;
//           if (newUser) {
//             if (typeof newUser.totalgold !== "undefined") {
//               console.log("total gold printed:", newUser.totalgold);
//               setUserGold(newUser.totalgold);
//             }
//             if (typeof newUser.totaldiamond !== "undefined") {
//               console.log("total diamond printed:", newUser.totaldiamond);
//               setUserDiamond(newUser.totaldiamond);
//             }
//           }
//         }
//       )
//       .subscribe();

//     const fetchBalances = async () => {
//       const { data, error } = await supabase
//         .from("users")
//         .select("totalgold, totaldiamond")
//         .eq("email", email)
//         .single();

//       if (error) {
//         console.error("Error fetching balances:", error);
//         return;
//       }

//       if (data) {
//         setUserGold(data.totalgold || 0);
//         setUserDiamond(data.totaldiamond || 0);
//       }
//     };

//     fetchBalances();

//     return () => {
//       console.log("Removing Supabase listener for:", email);
//       supabase.removeChannel(channel);
//     };
//   }, [auth.currentUser?.email]);

//   const handleStickerSelect = (item) => {
//     console.log("item-------", item);
//     setGiftImageURL(item.imageUrl);
//     setSelectedSticker(item);
//   };

//   const closeModal = () => {
//     setShowStickerPicker(false);
//   };

//   const handleSend = async () => {
//     if (!selectedSticker) return;

//     if (auth.currentUser) {
//       const userEmail = auth.currentUser.email;

//       const { data: userData, error: userError } = await supabase
//         .from("users")
//         .select("totalgold, totaldiamond")
//         .eq("email", userEmail)
//         .single();

//       if (userError) {
//         console.error("Error fetching user:", userError);
//         return;
//       }

//       if (!userData) {
//         console.log("No user found!");
//         return;
//       }

//       const cost = selectedSticker.coins * quantity;

//       if (isTypeGold) {
//         const currentGold = userData.totalgold || 0;

//         if (cost <= currentGold) {
//           const newGoldBalance = currentGold - cost;

//           const { error: updateError } = await supabase
//             .from("users")
//             .update({ totalgold: newGoldBalance })
//             .eq("email", userEmail);

//           if (updateError) {
//             console.error("Error updating gold:", updateError);
//             return;
//           }

//           setUserGold(newGoldBalance);
//           await sendMessageWithImage(route.params.id, giftImageURL);
//           setShowStickerPicker(false);
//           closeModal();
//         } else {
//           alert(
//             "Insufficient Gold Coins\nYou do not have enough Gold to make this purchase."
//           );
//           return;
//         }
//       } else {
//         const currentDiamond = userData.totaldiamond || 0;

//         if (cost <= currentDiamond) {
//           const newDiamondBalance = currentDiamond - cost;

//           const { error: updateError } = await supabase
//             .from("users")
//             .update({ totaldiamond: newDiamondBalance })
//             .eq("email", userEmail);

//           if (updateError) {
//             console.error("Error updating diamonds:", updateError);
//             return;
//           }

//           setUserDiamond(newDiamondBalance);
//           await sendMessageWithImage(route.params.id, giftImageURL);
//           setShowStickerPicker(false);
//           closeModal();
//         } else {
//           alert(
//             "Insufficient Diamond Coins\nYou do not have enough Diamonds to make this purchase."
//           );
//           return;
//         }
//       }
//     }
//   };

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setTimeLeft((prev) => {
//         if (prev <= 1) return 60 * 60;
//         return prev - 1;
//       });
//     }, 1000);
//     return () => clearInterval(timer);
//   }, []);

//   const formatTime = (seconds) => {
//     const m = Math.floor(seconds / 60);
//     const s = seconds % 60;
//     return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
//   };

//   const Header = () => (
//     <div className="header">
//       <button onClick={() => navigate(-1)} className="backButton">
//         <IoIosArrowBack size={24} color="#fff" />
//       </button>
//       <img 
//         src={route.params.image || 'https://i.pravatar.cc/300'} 
//         className="avatar"
//         alt="User avatar"
//       />
//       <div className="headerTextContainer">
//         <div className="headerName">
//           {route.params.name || route.params.email}
//         </div>
//         <div className="headerStatus">
//           {isTyping ? 'typing...' : isOnline ? 'online' : 'offline'}
//         </div>
//       </div>
//       <button className="callButton">
//         <IoIosCall size={24} color="#fff" />
//       </button>
//       <button className="videoCallButton">
//         <IoIosVideocam size={24} color="#fff" />
//       </button>
//     </div>
//   );

//   const updateTypingStatus = async (status) => {
//     const chatDocRef = doc(db, "chats", route.params.id);
//     await updateDoc(chatDocRef, { isTyping: status });
//   };

//   useEffect(() => {
//     if (!auth.currentUser?.email) return;

//     const fetchUser = async () => {
//       const { data, error } = await supabase
//         .from("users")
//         .select("issubscription")
//         .eq("email", auth.currentUser.email)
//         .maybeSingle();

//       if (error) {
//         console.error("Error fetching user subscription:", error);
//         return;
//       }

//       if (data) {
//         setIsUserSubscription(!!data.issubscription);
//         console.log("Initial subscription status:", data.issubscription);
//       }
//     };

//     fetchUser();

//     const channel = supabase
//       .channel("subscription-status-channel")
//       .on(
//         "postgres_changes",
//         {
//           event: "UPDATE",
//           schema: "public",
//           table: "users",
//           filter: `email=eq.${auth.currentUser.email}`,
//         },
//         (payload) => {
//           console.log("Subscription updated:", payload.new.issubscription);
//           setIsUserSubscription(!!payload.new.issubscription);
//         }
//       )
//       .subscribe();

//     return () => {
//       supabase.removeChannel(channel);
//     };
//   }, [auth.currentUser?.email]);

//   const getTickIcon = (status) => {
//     if (!IsUserSubscription) return "";
//     switch (status) {
//       case "sent":
//         return "✓";
//       case "delivered":
//         return "✓✓";
//       case "read":
//         return "✓✓";
//       default:
//         return "";
//     }
//   };

//   const MessageBubble = ({ message, selfEmail, chatId }) => {
//     const isSelf = message.user?._id === selfEmail;
//     const [videoPaused, setVideoPaused] = useState(true);

//     return (
//       <div className={`messageContainer ${isSelf ? 'selfMessageContainer' : 'otherMessageContainer'}`}>
//         <div className={`messageBubble ${isSelf ? 'selfBubble' : 'otherBubble'}`}>
//           {message.image && (
//             <img
//               src={message.image}
//               className="messageImage"
//               alt="Message attachment"
//             />
//           )}

//           {message.video && (
//             <div className="videoContainer">
//               <video
//                 src={message.video}
//                 className="messageVideo"
//                 paused={videoPaused}
//                 controls
//               />
//               <button 
//                 className="playButton"
//                 onClick={() => setVideoPaused(!videoPaused)}
//               >
//                 {videoPaused ? <IoIosPlay size={24} color="#fff" /> : <IoIosPause size={24} color="#fff" />}
//               </button>
//             </div>
//           )}

//           {message.text ? (
//             <div className={isSelf ? 'selfMessageText' : 'otherMessageText'}>
//               {message.text}
//             </div>
//           ) : null}

//           <div className="messageStatusContainer">
//             <div className={`messageTime ${isSelf ? 'selfMessageTime' : 'otherMessageTime'}`}>
//               {message.createdAt ? new Date(message.createdAt).toLocaleTimeString([], { 
//                 hour: '2-digit', 
//                 minute: '2-digit' 
//               }) : ''}
//             </div>
//             {isSelf && (
//               <div className={`messageStatus ${
//                 message.status === "read" || message.status === "delivered" ? 
//                 'deliveredStatus' : 'sentStatus'
//               }`}>
//                 {getTickIcon(message.status)}
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     );
//   };

//   const handleChangeText = (value) => {
//     setInputText(value);
//     setTypingStatus(route.params.id, currentEmail, true);
//     setIsTyping(true);

//     if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);

//     typingTimeoutRef.current = setTimeout(() => {
//       setTypingStatus(route.params.id, currentEmail, false);
//       setIsTyping(false);
//     }, 1500);
//   };

//   useEffect(() => {
//     const handleBeforeUnload = () => {
//       setTypingStatus(route.params.id, currentEmail, false);
//     };

//     window.addEventListener('beforeunload', handleBeforeUnload);
    
//     return () => {
//       window.removeEventListener('beforeunload', handleBeforeUnload);
//     };
//   }, [navigation]);

//   const sendMessage = async (chatId, msg) => {
//     try {
//       console.log("Sending message to chat ID:", chatId);
//       console.log("Sending message to currentEmail:", currentEmail);

//       const newMsg = {
//         _id: uuidv4(),
//         createdAt: new Date().toISOString(),
//         text: msg,
//         status: "sent",
//         seenBy: [],
//         user: {
//           _id: currentEmail,
//           name: auth.currentUser?.displayName,
//           avatar: "https://i.pravatar.cc/300",
//         },
//       };

//       sendFcmNotification(
//         fcmToken,
//         auth?.currentUser?.email,
//         newMsg.text,
//         accessToken,
//         { Peeremail: auth?.currentUser?.email, type: "Message_Notification"}
//       );

//       const { error: insertError } = await supabase
//         .from("chat_messages")
//         .insert([
//           {
//             chat_id: chatId,
//             user_email: currentEmail,
//             message: newMsg,
//           },
//         ]);

//       if (insertError) throw insertError;

//       await supabase
//         .from("chats")
//         .update({
//           last_message: newMsg.text,
//           last_updated: new Date().toISOString(),
//         })
//         .eq("id", chatId);

//       setInputText("");
//       setTypingStatus(chatId, currentEmail, false);
//       setIsTyping(false);

//       console.log("✅ Message sent:", newMsg);
//     } catch (err) {
//       console.error("❌ sendMessage error:", err);
//     }
//   };

//   const sendMessageWithImage = async (chatId, imageUrl) => {
//     try {
//       const senderEmail = auth.currentUser?.email;
//       const senderName = auth.currentUser?.displayName;
//       const receiverEmail = route.params.email;

//       const giftTypeValue = isTypeGold ? "gold" : "diamond";

//       const newMsg = {
//         _id: uuidv4(),
//         createdAt: new Date().toISOString(),
//         text: "",
//         giftType: giftTypeValue,
//         giftName: selectedSticker?.name || "",
//         giftAmount: selectedSticker?.coins * quantity,
//         giftNumber: quantity,
//         image: imageUrl,
//         status: "sent",
//         seenBy: [],
//         user: {
//           _id: senderEmail,
//           name: senderName,
//           avatar: "https://i.pravatar.cc/300",
//         },
//       };

//       const { error: insertError } = await supabase
//         .from("chat_messages")
//         .insert([
//           {
//             chat_id: chatId,
//             user_email: senderEmail,
//             message: newMsg,
//           },
//         ]);

//       if (insertError) throw insertError;

//       await supabase
//         .from("chats")
//         .update({
//           last_message: "[gift 🎁]",
//           last_updated: new Date().toISOString(),
//         })
//         .eq("id", chatId);

//       const newGift = {
//         giftUrl: imageUrl,
//         giftType: giftTypeValue,
//         giftName: selectedSticker?.name || "",
//         giftAmount: selectedSticker?.coins * quantity,
//         giftNumber: quantity,
//         from: senderName,
//         fromEmail: senderEmail,
//         date: new Date().toISOString(),
//       };

//       const { data: userData, error: userError } = await supabase
//         .from("users")
//         .select("gifts, goldbalance, diamondbalance")
//         .eq("email", receiverEmail)
//         .single();

//       if (userError) throw userError;

//       const existingGifts = userData?.gifts || [];
//       const goldBalance = (selectedSticker?.coins * quantity) + userData?.goldbalance || 0;
//       const diamondbalance = (selectedSticker?.coins * quantity) + userData?.diamondbalance || 0;

//       if (giftTypeValue === "gold") {
//         const { error: updateUserError } = await supabase
//           .from("users")
//           .update({
//             gifts: [...existingGifts, newGift],
//             goldbalance: goldBalance,
//           })
//           .eq("email", receiverEmail);

//         if (updateUserError) throw updateUserError;
//       } else {
//         const { error: updateUserError } = await supabase
//           .from("users")
//           .update({
//             gifts: [...existingGifts, newGift],
//             diamondbalance: diamondbalance
//           })
//           .eq("email", receiverEmail);

//         if (updateUserError) throw updateUserError;
//       }

//       console.log("✅ Gift message sent:", newMsg);
//     } catch (err) {
//       console.error("❌ sendMessageWithImage error:", err);
//     }
//   };

//   const pickMedia = (chatId) => {
//     const input = document.createElement('input');
//     input.type = 'file';
//     input.accept = 'image/*';
//     input.onchange = async (e) => {
//       const file = e.target.files[0];
//       if (file) {
//         await handleMediaUpload(chatId, URL.createObjectURL(file), 'image', file.name);
//       }
//     };
//     input.click();
//   };

//   const handleMediaUpload = async (chatId, uri, type, fileName) => {
//     try {
//       setUploading(true);

//       const folder = "images";
//       const ext = "jpg";
//       const uniqueName = fileName || `${Date.now()}.${ext}`;
//       const filePath = `${auth.currentUser.email}/${folder}/${uniqueName}`;

//       const response = await fetch(uri);
//       const blob = await response.blob();

//       const { error } = await supabase.storage
//         .from("chat_messages")
//         .upload(filePath, blob, {
//           contentType: "image/jpeg",
//           upsert: true,
//         });

//       if (error) throw error;

//       const { data } = supabase.storage.from("chat_messages").getPublicUrl(filePath);
//       console.log("✅ Media uploaded:", data.publicUrl);

//       await sendMessageWithMedia(chatId, data.publicUrl, "image");

//     } catch (err) {
//       console.error("Media upload failed:", err);
//       alert("Error", "Media upload failed");
//     } finally {
//       setUploading(false);
//     }
//   };

//   const sendMessageWithMedia = async (chatId, mediaUrl, type) => {
//     const now = new Date();
//     const expiresAt = new Date(now.getTime() + 2 * 60 * 60 * 1000).toISOString();

//     const newMsg = {
//       _id: uuidv4(),
//       createdAt: now.toISOString(),
//       expiresAt,
//       text: null,
//       image: mediaUrl,
//       type: "image",
//       status: "sent",
//       user: {
//         _id: auth.currentUser.email,
//         name: auth.currentUser.displayName,
//         avatar: "https://i.pravatar.cc/300",
//       },
//     };

//     const { error } = await supabase.from("chat_messages").insert([
//       {
//         chat_id: chatId,
//         user_email: auth.currentUser.email,
//         message: newMsg,
//         expires_at: expiresAt,
//       },
//     ]);

//     if (error) console.error("Send message failed:", error);
//   };

//   const handleEmojiPanel = () => {
//     setModal((prev) => !prev);
//   };

//   const toggleStickerPicker = () => {
//     setShowStickerPicker(prev => !prev);
//   };

//   return (
//     <div className="safeArea">
//       <div className="container">
//         <div className="keyboardAvoidView">
//           {uploading && (
//             <div className="uploadOverlay">
//               <div className="activityIndicator"></div>
//               <div className="uploadText">Uploading image...</div>
//             </div>
//           )}

//           <Header />

//           <div className="messagesContainer">
//             {messages.map((item, index) => (
//               <MessageBubble 
//                 key={item._id ?? item.id ?? index} 
//                 message={item} 
//                 selfEmail={auth.currentUser?.email} 
//               />
//             ))}
//           </div>

//           {showStickerPicker && (
//             <div className="modalOverlay">
//               <div className="stickerModal">
//                 <div className="banner">
//                   <div className="bannerContent">
//                     <MdLocalOffer size={16} color="#fff" />
//                     <div className="bannerText">Get newbie bonus, recharge for free lottery.</div>
//                   </div>
//                   <div className="timerBox">
//                     <div className="timerText">{formatTime(timeLeft)}</div>
//                   </div>
//                 </div>

//                 <div className="stickerModalHeader">
//                   <div className="stickerModalTitle">Send a Gift</div>

//                   <div className="headerRight">
//                     <div className="coinsBox">
//                       <div className="coinItem">
//                         <MdDiamond size={18} color="#9b59b6" />
//                         <div className="coinText">{userDiamond}</div>
//                       </div>
//                       <div className="coinItem">
//                         <FaCoins size={18} color="#f1c40f" />
//                         <div className="coinText">{userGold}</div>
//                       </div>
//                     </div>

//                     <button onClick={closeModal} className="closeButton">
//                       <IoIosClose size={24} color="#000" />
//                     </button>
//                   </div>
//                 </div>

//                 <div className="tabRow">
//                   <button 
//                     className={`tabButton ${activeTab === "gold" && 'activeTab'}`} 
//                     onClick={() => {
//                       setisTypeGold(true);
//                       setActiveTab("gold");
//                     }}
//                   >
//                     <FaCoins size={16} color="#f1c40f" />
//                     <div className="tabText">Gold</div>
//                   </button>

//                   <button 
//                     className={`tabButton ${activeTab === "diamond" && 'activeTab'}`} 
//                     onClick={() => {
//                       setisTypeGold(false);
//                       setActiveTab("diamond");
//                     }}
//                   >
//                     <MdDiamond size={16} color="#9b59b6" />
//                     <div className="tabText">Diamond</div>
//                   </button>
//                 </div>

//                 {loading ? (
//                   <div className="loadingContainer">
//                     <div className="activityIndicator"></div>
//                   </div>
//                 ) : (
//                   <div className="listContainer">
//                     {filteredGifts.map((item, idx) => (
//                       <button
//                         key={idx}
//                         className={`stickerItem ${selectedSticker === item && 'selectedSticker'}`}
//                         onClick={() => handleStickerSelect(item)}
//                       >
//                         <div className="stickerImageContainer">
//                           <img src={item.imageUrl} className="stickerImage" alt="Sticker" />
//                           {item.isNew && (
//                             <div className="newBadge">
//                               <div className="newText">NEW</div>
//                             </div>
//                           )}
//                         </div>
//                         <div className="coinRow">
//                           {item.isTypeDiamond ? (
//                             <MdDiamond size={12} color="#3498db" />
//                           ) : (
//                             <FaCoins size={12} color="#f1c40f" />
//                           )}
//                           <div className="coinLabel">{item.coins}</div>
//                         </div>
//                       </button>
//                     ))}
//                   </div>
//                 )}

//                 <div className="footer">
//                   <div className="avatar">
//                     <div className="avatarLabel">
//                       {route.params.chatName?.split(' ').reduce((prev, current) => `${prev}${current[0]}`, '')}
//                     </div>
//                   </div>

//                   <div className="userName">{route.params.chatName}</div>

//                   <select 
//                     value={quantity}
//                     onChange={(e) => setQuantity(Number(e.target.value))}
//                     className="dropdown"
//                   >
//                     {Array.from({ length: 50 }, (_, i) => (
//                       <option key={i + 1} value={i + 1}>
//                         {i + 1}
//                       </option>
//                     ))}
//                   </select>

//                   <button 
//                     className={`sendButton ${!selectedSticker && 'sendButtonDisabled'}`} 
//                     onClick={handleSend}
//                     disabled={!selectedSticker}
//                   >
//                     <div className="sendText">
//                       {selectedSticker ? `Send (${selectedSticker.coins * quantity})` : 'Send'}
//                     </div>
//                   </button>
//                 </div>
//               </div>
//             </div>
//           )}

//           <div className="inputContainer">
//             <button 
//               onClick={toggleStickerPicker}
//               className="iconButton"
//             >
//               <IoIosGift size={28} color={'#FF512F'} />
//             </button>

//             <input
//               value={inputText}
//               onChange={(e) => handleChangeText(e.target.value)}
//               placeholder={
//                 isChatDisabled
//                   ? "You can't send messages to this user"
//                   : "Type a message..."
//               }
//               disabled={isChatDisabled}
//               className="input"
//               multiline
//             />

//             <button 
//               className="iconButton" 
//               onClick={() => pickMedia(route.params.id)}
//             >
//               <IoIosImages size={28} color="#FF512F" />
//             </button>

//             <button 
//               onClick={() => inputText.trim() && sendMessage(route.params.id, inputText)}
//               className={`sendButton ${!inputText.trim() && 'sendButtonDisabled'}`}
//               disabled={!inputText.trim()}
//             >
//               <IoIosSend size={24} color="#fff" />
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// Chat.propTypes = {
//   route: PropTypes.object,
// };

// export default Chat;



import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { doc, updateDoc } from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';
import PropTypes from 'prop-types';

// Icons
import {
  IoIosSend,
  IoIosImages,
  IoIosGift,
  IoIosArrowBack,
  IoIosCall,
  IoIosVideocam,
  IoIosClose,
  IoIosPlay,
  IoIosPause
} from 'react-icons/io';
import { MdDiamond, MdLocalOffer } from 'react-icons/md';
import { FaCoins } from 'react-icons/fa';

// Firebase & Supabase
import { auth, db } from '../../firebase/config';





// Styles
import './Chat.css';
import { supabase } from '../../firebase/supabaseClient';
import { setTypingStatus } from './setTypingStatus';
import usePaidStickers from './usePaidStickers';

const Chat = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const routeParams = location.state || {};

  // State Management
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [uploading, setUploading] = useState(false);
  const [showStickerPicker, setShowStickerPicker] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [isChatDisabled, setIsChatDisabled] = useState(false);
  const [selectedSticker, setSelectedSticker] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState("gold");
  const [userGold, setUserGold] = useState(0);
  const [userDiamond, setUserDiamond] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60 * 60);

  // Refs
  const typingTimeoutRef = useRef(null);
  const messagesEndRef = useRef(null);

  // Hooks
  const { giftImages, loading: stickersLoading } = usePaidStickers();
  const currentEmail = auth?.currentUser?.email;

  // Derived State
  const filteredGifts = useCallback(() => 
    giftImages.filter(item => 
      activeTab === "diamond" ? item.isTypeDiamond : !item.isTypeDiamond
    ), [giftImages, activeTab]
  );

  // Effects
  useEffect(() => {
    console.log("🛣️ Chat Screen Route:", routeParams);
  }, [routeParams]);

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    // Timer for sticker banner
    const timer = setInterval(() => {
      setTimeLeft(prev => prev <= 1 ? 60 * 60 : prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Fetch user balances
    const fetchUserBalances = async () => {
      const email = auth.currentUser?.email;
      if (!email) return;

      try {
        const { data, error } = await supabase
          .from("users")
          .select("totalgold, totaldiamond")
          .eq("email", email)
          .single();

        if (data) {
          setUserGold(data.totalgold || 0);
          setUserDiamond(data.totaldiamond || 0);
        }
      } catch (error) {
        console.error("Error fetching balances:", error);
      }
    };

    fetchUserBalances();

    // Real-time balance updates
    const channel = supabase
      .channel("user-balance-changes")
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "users", filter: `email=eq.${auth.currentUser?.email}` },
        (payload) => {
          const newUser = payload.new;
          setUserGold(newUser.totalgold || 0);
          setUserDiamond(newUser.totaldiamond || 0);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    // Block status monitoring
    const checkBlockStatus = async () => {
      try {
        const { data: targetData } = await supabase
          .from("blockusers")
          .select("TotalBlockUser")
          .eq("email", routeParams.email)
          .single();

        const isBlocked = Array.isArray(targetData?.TotalBlockUser) 
          ? targetData.TotalBlockUser.some(u => u.email === currentEmail && u.isblock)
          : false;

        setIsChatDisabled(isBlocked);
      } catch (error) {
        console.error("Error checking block status:", error);
      }
    };

    if (routeParams.email && currentEmail) {
      checkBlockStatus();
    }
  }, [routeParams.email, currentEmail]);

  // Handlers
  const handleStickerSelect = useCallback((item) => {
    setSelectedSticker(item);
  }, []);

  const closeModal = useCallback(() => {
    setShowStickerPicker(false);
    setSelectedSticker(null);
  }, []);

  const handleSend = async () => {
    if (!inputText.trim()) return;

    try {
      await sendMessage(routeParams.id, inputText.trim());
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message");
    }
  };

  const handleSendSticker = async () => {
    if (!selectedSticker) return;

    try {
      const userEmail = auth.currentUser.email;
      const { data: userData } = await supabase
        .from("users")
        .select("totalgold, totaldiamond")
        .eq("email", userEmail)
        .single();

      if (!userData) {
        alert("User data not found");
        return;
      }

      const cost = selectedSticker.coins * quantity;
      const isGold = activeTab === "gold";
      const currentBalance = isGold ? userData.totalgold : userData.totaldiamond;

      if (cost > currentBalance) {
        alert(`Insufficient ${isGold ? 'Gold' : 'Diamond'} Coins`);
        return;
      }

      // Update balance
      const updateField = isGold ? { totalgold: currentBalance - cost } : { totaldiamond: currentBalance - cost };
      await supabase
        .from("users")
        .update(updateField)
        .eq("email", userEmail);

      // Send sticker message
      await sendMessageWithImage(routeParams.id, selectedSticker.imageUrl);
      closeModal();
    } catch (error) {
      console.error("Error sending sticker:", error);
      alert("Failed to send sticker");
    }
  };

  const handleChangeText = useCallback((value) => {
    setInputText(value);
    
    // Typing indicator
    setTypingStatus(routeParams.id, currentEmail, true);
    setIsTyping(true);

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      setTypingStatus(routeParams.id, currentEmail, false);
      setIsTyping(false);
    }, 1500);
  }, [routeParams.id, currentEmail]);

  const pickMedia = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,video/*';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (file) {
        await handleMediaUpload(routeParams.id, URL.createObjectURL(file), file.type.startsWith('image') ? 'image' : 'video', file.name);
      }
    };
    input.click();
  }, [routeParams.id]);

  const handleMediaUpload = async (chatId, uri, type, fileName) => {
    try {
      setUploading(true);
      
      const folder = type === 'image' ? "images" : "videos";
      const ext = fileName.split('.').pop() || (type === 'image' ? 'jpg' : 'mp4');
      const uniqueName = `${Date.now()}.${ext}`;
      const filePath = `${auth.currentUser.email}/${folder}/${uniqueName}`;

      const response = await fetch(uri);
      const blob = await response.blob();

      const { error } = await supabase.storage
        .from("chat_messages")
        .upload(filePath, blob, {
          contentType: type === 'image' ? 'image/jpeg' : 'video/mp4',
          upsert: false,
        });

      if (error) throw error;

      const { data } = supabase.storage.from("chat_messages").getPublicUrl(filePath);
      await sendMessageWithMedia(chatId, data.publicUrl, type);

    } catch (err) {
      console.error("Media upload failed:", err);
      alert("Media upload failed");
    } finally {
      setUploading(false);
    }
  };

  // API Functions
  const sendMessage = async (chatId, text) => {
    const newMsg = {
      _id: uuidv4(),
      createdAt: new Date().toISOString(),
      text,
      status: "sent",
      seenBy: [],
      user: {
        _id: currentEmail,
        name: auth.currentUser?.displayName || currentEmail,
        avatar: auth.currentUser?.photoURL || "https://i.pravatar.cc/300",
      },
    };

    const { error } = await supabase
      .from("chat_messages")
      .insert([{
        chat_id: chatId,
        user_email: currentEmail,
        message: newMsg,
      }]);

    if (error) throw error;

    await supabase
      .from("chats")
      .update({
        last_message: text,
        last_updated: new Date().toISOString(),
      })
      .eq("id", chatId);

    setInputText("");
    setTypingStatus(chatId, currentEmail, false);
    setIsTyping(false);
  };

  const sendMessageWithImage = async (chatId, imageUrl) => {
    const newMsg = {
      _id: uuidv4(),
      createdAt: new Date().toISOString(),
      text: "",
      giftType: activeTab,
      giftName: selectedSticker?.name || "",
      giftAmount: selectedSticker?.coins * quantity,
      giftNumber: quantity,
      image: imageUrl,
      status: "sent",
      user: {
        _id: auth.currentUser.email,
        name: auth.currentUser.displayName || auth.currentUser.email,
        avatar: auth.currentUser.photoURL || "https://i.pravatar.cc/300",
      },
    };

    const { error } = await supabase
      .from("chat_messages")
      .insert([{
        chat_id: chatId,
        user_email: auth.currentUser.email,
        message: newMsg,
      }]);

    if (error) throw error;

    await supabase
      .from("chats")
      .update({
        last_message: "[gift 🎁]",
        last_updated: new Date().toISOString(),
      })
      .eq("id", chatId);
  };

  const sendMessageWithMedia = async (chatId, mediaUrl, type) => {
    const newMsg = {
      _id: uuidv4(),
      createdAt: new Date().toISOString(),
      text: null,
      [type]: mediaUrl,
      type,
      status: "sent",
      user: {
        _id: auth.currentUser.email,
        name: auth.currentUser.displayName || auth.currentUser.email,
        avatar: auth.currentUser.photoURL || "https://i.pravatar.cc/300",
      },
    };

    const { error } = await supabase
      .from("chat_messages")
      .insert([{
        chat_id: chatId,
        user_email: auth.currentUser.email,
        message: newMsg,
      }]);

    if (error) console.error("Send message failed:", error);
  };

  // Helper Functions
  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  // Components
  const Header = () => (
    <div className="header">
      <button onClick={() => navigate(-1)} className="backButton">
        <IoIosArrowBack size={24} />
      </button>
      <img 
        src={routeParams.avatar || routeParams.image || 'https://i.pravatar.cc/300'} 
        className="avatar"
        alt={routeParams.name || 'User'}
      />
      <div className="headerTextContainer">
        <div className="headerName">
          {routeParams.name || routeParams.email || 'Unknown User'}
        </div>
        <div className="headerStatus">
          {isTyping ? 'typing...' : isOnline ? 'online' : 'offline'}
        </div>
      </div>
      <div className="headerActions">
        <button className="callButton">
          <IoIosCall size={24} />
        </button>
        <button className="videoCallButton">
          <IoIosVideocam size={24} />
        </button>
      </div>
    </div>
  );

  const MessageBubble = React.memo(({ message, selfEmail }) => {
    const isSelf = message.user?._id === selfEmail;
    const [isVideoPaused, setIsVideoPaused] = useState(true);

    return (
      <div className={`messageContainer ${isSelf ? 'selfMessageContainer' : 'otherMessageContainer'}`}>
        <div className={`messageBubble ${isSelf ? 'selfBubble' : 'otherBubble'}`}>
          {message.image && (
            <img
              src={message.image}
              className="messageImage"
              alt="Shared content"
              loading="lazy"
            />
          )}

          {message.video && (
            <div className="videoContainer">
              <video
                src={message.video}
                className="messageVideo"
                controls
                onPlay={() => setIsVideoPaused(false)}
                onPause={() => setIsVideoPaused(true)}
              />
              <button 
                className="playButton"
                onClick={() => setIsVideoPaused(!isVideoPaused)}
              >
                {isVideoPaused ? <IoIosPlay size={24} /> : <IoIosPause size={24} />}
              </button>
            </div>
          )}

          {message.text && (
            <div className={`messageText ${isSelf ? 'selfMessageText' : 'otherMessageText'}`}>
              {message.text}
            </div>
          )}

          <div className="messageMeta">
            <span className="messageTime">
              {new Date(message.createdAt).toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </span>
            {isSelf && (
              <span className="messageStatus">
                {message.status === "read" ? "✓✓" : message.status === "delivered" ? "✓✓" : "✓"}
              </span>
            )}
          </div>
        </div>
      </div>
    );
  });

  const StickerModal = () => (
    <div className="modalOverlay">
      <div className="stickerModal">
        {/* Banner */}
        <div className="banner">
          <div className="bannerContent">
            <MdLocalOffer size={16} />
            <span>Get newbie bonus, recharge for free lottery.</span>
          </div>
          <div className="timerBox">
            <span>{formatTime(timeLeft)}</span>
          </div>
        </div>

        {/* Header */}
        <div className="stickerModalHeader">
          <h3>Send a Gift</h3>
          <div className="headerRight">
            <div className="coinsBox">
              <div className="coinItem">
                <MdDiamond size={18} />
                <span>{userDiamond}</span>
              </div>
              <div className="coinItem">
                <FaCoins size={18} />
                <span>{userGold}</span>
              </div>
            </div>
            <button onClick={closeModal} className="closeButton">
              <IoIosClose size={24} />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="tabRow">
          {[
            { key: "gold", icon: FaCoins, label: "Gold" },
            { key: "diamond", icon: MdDiamond, label: "Diamond" }
          ].map(({ key, icon: Icon, label }) => (
            <button
              key={key}
              className={`tabButton ${activeTab === key && 'activeTab'}`}
              onClick={() => setActiveTab(key)}
            >
              <Icon size={16} />
              <span>{label}</span>
            </button>
          ))}
        </div>

        {/* Stickers Grid */}
        {stickersLoading ? (
          <div className="loadingContainer">
            <div className="spinner"></div>
          </div>
        ) : (
          <div className="stickersGrid">
            {filteredGifts().map((item, idx) => (
              <button
                key={idx}
                className={`stickerItem ${selectedSticker === item && 'selected'}`}
                onClick={() => handleStickerSelect(item)}
              >
                <div className="stickerImageContainer">
                  <img src={item.imageUrl} alt={item.name} loading="lazy" />
                  {item.isNew && <span className="newBadge">NEW</span>}
                </div>
                <div className="stickerCost">
                  {item.isTypeDiamond ? <MdDiamond size={12} /> : <FaCoins size={12} />}
                  <span>{item.coins}</span>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="stickerFooter">
          <div className="recipientInfo">
            <div className="recipientAvatar">
              {routeParams.name?.charAt(0) || 'U'}
            </div>
            <span className="recipientName">{routeParams.name || 'User'}</span>
          </div>
          
          <select 
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
            className="quantitySelect"
          >
            {Array.from({ length: 10 }, (_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>

          <button 
            className={`sendButton ${!selectedSticker && 'disabled'}`}
            onClick={handleSendSticker}
            disabled={!selectedSticker}
          >
            Send {selectedSticker && `(${selectedSticker.coins * quantity})`}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="chatContainer">
      {uploading && (
        <div className="uploadOverlay">
          <div className="spinner"></div>
          <span>Uploading...</span>
        </div>
      )}

      <Header />

      <div className="messagesContainer">
        {messages.map((message, index) => (
          <MessageBubble
            key={message._id || index}
            message={message}
            selfEmail={currentEmail}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {showStickerPicker && <StickerModal />}

      <div className="inputContainer">
        <button 
          onClick={() => setShowStickerPicker(true)}
          className="iconButton"
          disabled={isChatDisabled}
        >
          <IoIosGift size={28} />
        </button>

        <input
          value={inputText}
          onChange={(e) => handleChangeText(e.target.value)}
          placeholder={
            isChatDisabled
              ? "You can't send messages to this user"
              : "Type a message..."
          }
          disabled={isChatDisabled}
          className="messageInput"
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
        />

        <button 
          className="iconButton"
          onClick={pickMedia}
          disabled={isChatDisabled || uploading}
        >
          <IoIosImages size={28} />
        </button>

        <button 
          onClick={handleSend}
          className={`sendButton ${!inputText.trim() && 'disabled'}`}
          disabled={!inputText.trim() || isChatDisabled || uploading}
        >
          <IoIosSend size={24} />
        </button>
      </div>
    </div>
  );
};

Chat.propTypes = {
  route: PropTypes.object,
};

export default Chat;