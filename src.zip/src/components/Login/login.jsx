import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../../firebase/config';
import { supabase } from '../../firebase/supabaseClient';
import { doc, updateDoc, getDoc } from 'firebase/firestore';
import '../../components/Login/Login.css';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [fadeIn, setFadeIn] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    setFadeIn(true); // Trigger fade-in animation
  }, []);

  const setUserOnline = async (email) => {
    try {
      const userRef = doc(db, "users", email);
      const docSnap = await getDoc(userRef);
      if (docSnap.exists()) {
        await updateDoc(userRef, { isActiveStatus: true });
        console.log("User set online");
      }
    } catch (error) {
      console.error("Error setting user online:", error);
    }
  };

  const onHandleLogin = async (e) => {
    e.preventDefault();
    if (email && password) {
      try {
        const cred = await signInWithEmailAndPassword(auth, email, password);
        const cleanedEmail = cred.user.email.trim().toLowerCase();
        localStorage.setItem("email", cleanedEmail);

        // Get admin status from Supabase
        const { data, error } = await supabase
          .from("users")
          .select("isTypeAdmin")
          .eq("email", cleanedEmail)
          .single();

        if (error) {
          alert("Supabase error: " + error.message);
          return;
        }

        localStorage.setItem("isTypeAdmin", JSON.stringify(data.isTypeAdmin));

        // Update user active status
        await supabase
          .from("users")
          .update({
            isactivestatus: true,
            iscallingfrom: "",
            isoncallstatus: false,
            password: password
          })
          .eq("email", cleanedEmail);

        await setUserOnline(cleanedEmail);
        navigate("/chats");
      } catch (err) {
        alert("Login error: " + err.message);
      }
    }
  };

  return (
    <div className="gradient-background">
      <div className="safe-area">
        <div className={`login-container ${fadeIn ? 'fade-in' : ''}`}>

          {/* Header */}
          <div className="header">
            <h1 className="title">Login</h1>
            <p className="subtitle">Welcome back! Please sign in to continue</p>
          </div>

          {/* Login Form */}
          <form className="login-form" onSubmit={onHandleLogin}>

            {/* Email */}
            <div className="input-container">
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="form-input"
              />
            </div>

            {/* Password */}
            <div className="input-container">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="form-input"
              />
              <button
                type="button"
                className="eye-button"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? '🙈' : '👁️'}
              </button>
            </div>

            {/* Forgot Password */}
            <div className="forgot-password-container">
              <Link to="/forgot-password" className="forgot-password">
                Forgot password?
              </Link>
            </div>

            {/* Submit */}
            <button type="submit" className="login-button">
              Login
            </button>

            {/* Signup Link */}
            <div className="signup-container">
              <span>Don't have an account? </span>
              <Link to="/signup" className="signup-link">Sign Up</Link>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
}
