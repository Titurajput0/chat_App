// ChatHeader.jsx
import React, { useEffect, useState, useRef } from "react";
import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";
// import { supabase } from "../config/supabaseClient";
import { supabase} from '../../firebase/supabaseClient';
import TypingIndicator from "../components/TypingIndicator"; // adjust path
import { FaCircle } from "react-icons/fa";
// import "./ChatHeader.css"; // optional CSS file
import '../../components/ChatHeader.css';

const ChatHeader = ({ chatName, chatId, email, avatar, about }) => {
  const navigate = useNavigate();
  const [isOnline, setIsOnline] = useState(false);
  const [selfEmail, setSelfEmail] = useState("");
  const channelRef = useRef(null);

  useEffect(() => {
    let mounted = true;

    const startListeners = async () => {
      const storedEmail = localStorage.getItem("email");
      if (!storedEmail) {
        console.warn("No email found in localStorage");
        return;
      }
      if (!mounted) return;
      setSelfEmail(storedEmail);

      // initial status fetch for partner
      try {
        const { data: currentStatus, error: statusError } = await supabase
          .from("users")
          .select("isactivestatus")
          .eq("email", email)
          .single();

        if (!statusError && currentStatus) {
          setIsOnline(Boolean(currentStatus.isactivestatus));
        }
      } catch (err) {
        console.error("Error fetching status:", err);
      }

      // realtime subscription for partner status
      channelRef.current = supabase
        .channel(`user_status_${email}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "users",
            filter: `email=eq.${email}`,
          },
          (payload) => {
            if (!mounted) return;
            const newStatus = payload?.new?.isactivestatus;
            setIsOnline(Boolean(newStatus));
          }
        )
        .subscribe((status) => {
          // optional: log
        });

      // document visibility listener to update self user's online status
      const handleVisibility = async () => {
        const state = document.visibilityState;
        try {
          if (state === "visible") {
            await supabase
              .from("users")
              .update({ isactivestatus: true })
              .eq("email", storedEmail);
          } else {
            await supabase
              .from("users")
              .update({ isactivestatus: false })
              .eq("email", storedEmail);
          }
        } catch (err) {
          console.error("Failed to update isactivestatus:", err);
        }
      };

      document.addEventListener("visibilitychange", handleVisibility);

      // cleanup for this listener on unmount
      return () => {
        document.removeEventListener("visibilitychange", handleVisibility);
      };
    };

    // call and get cleanup handler for visibility listener (but that cleanup will also happen in outer return)
    const maybeCleanup = startListeners();

    return () => {
      mounted = false;
      // cleanup supabase channel
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
      // if startListeners returned a cleanup function, call it
      if (typeof maybeCleanup === "function") maybeCleanup();
    };
  }, [email]);

  const goToChatInfo = () => {
    // navigate and pass state
    navigate("/chat-info", { state: { chatId, chatName, avatar, about, isOnline } });
  };

  const initials = (name = "") =>
    name
      .split(" ")
      .map((s) => (s[0] || ""))
      .slice(0, 2)
      .join("")
      .toUpperCase();

  return (
    <div className="chat-header" onClick={goToChatInfo} role="button" tabIndex={0}>
      <div className="chat-header-left" onClick={goToChatInfo}>
        <div className="avatar-circle">
          {avatar ? (
            <img src={avatar} alt={chatName} className="avatar-img" />
          ) : (
            <div className="avatar-initials">{initials(chatName)}</div>
          )}
        </div>
        <div className="chat-meta">
          <div className="chat-name">{chatName}</div>
          <div className="chat-status">
            <FaCircle className="status-icon" style={{ color: isOnline ? "#24C55A" : "#D93E3E" }} />
            <span className="status-text">{isOnline ? "Online" : "Offline"}</span>
          </div>

          {selfEmail && (
            <TypingIndicator chatId={chatId} currentUserEmail={selfEmail} otherEmail={email} />
          )}
        </div>
      </div>
    </div>
  );
};

ChatHeader.propTypes = {
  chatName: PropTypes.string.isRequired,
  avatar: PropTypes.string,
  chatId: PropTypes.string.isRequired,
  email: PropTypes.string.isRequired,
  about: PropTypes.string,
};

export default ChatHeader;
