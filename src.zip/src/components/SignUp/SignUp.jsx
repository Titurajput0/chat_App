// import React, { useState } from "react";
// import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
// import { auth } from "../../firebase/config";
// import { supabase } from "../../firebase/supabaseClient";

// export default function SignUp() {
//   const [email, setEmail] = useState("");
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [dob, setDob] = useState("");
//   const [genderValue, setGenderValue] = useState("");
//   const [maritalValue, setMaritalValue] = useState("");
//   const [country, setCountry] = useState("");
//   const [profileImage, setProfileImage] = useState(null);
//   const [uploadedImageUrl, setUploadedImageUrl] = useState("");

//   const genderItems = [
//     { label: "Male", value: "male" },
//     { label: "Female", value: "female" },
//     { label: "Other", value: "other" },
//   ];

//   const maritalItems = [
//     { label: "Single", value: "single" },
//     { label: "Married", value: "married" },
//     { label: "Divorced", value: "divorced" },
//   ];

//   // Pick image from computer
//   const pickImage = async (e) => {
//     const file = e.target.files[0];
//     if (!file) return;
//     setProfileImage(URL.createObjectURL(file));

//     const url = await uploadImageToSupabase(file);
//     if (url) setUploadedImageUrl(url);
//   };

//   // Upload image to Supabase
//   const uploadImageToSupabase = async (file) => {
//     try {
//       const filePath = `${Date.now()}_${file.name}`;
//       const { data, error } = await supabase.storage
//         .from("signUp_Images")
//         .upload(filePath, file, { upsert: true });

//       if (error) throw error;

//       const { data: urlData } = supabase.storage
//         .from("signUp_Images")
//         .getPublicUrl(filePath);

//       return urlData.publicUrl;
//     } catch (err) {
//       alert("Failed to upload image");
//       console.error(err);
//       return null;
//     }
//   };

//   // Calculate age
//   const calculateAge = (birthDate) => {
//     const today = new Date();
//     const birth = new Date(birthDate);
//     let age = today.getFullYear() - birth.getFullYear();
//     const m = today.getMonth() - birth.getMonth();
//     if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
//     return age;
//   };

//   // Signup handler
//   const onHandleSignup = async () => {
//     if (!email || !password || !username || !dob || !genderValue || !maritalValue || !country || !uploadedImageUrl) {
//       alert("Please fill all fields");
//       return;
//     }

//     const userAge = calculateAge(dob);
//     if (userAge < 18) {
//       alert("You must be at least 18 years old.");
//       return;
//     }

//     try {
//       const cred = await createUserWithEmailAndPassword(auth, email, password);
//       await updateProfile(cred.user, { displayName: username });

//       const { data, error } = await supabase
//         .from("users")
//         .upsert([
//           {
//             id: cred.user.uid,
//             email: cred.user.email,
//             password,
//             avatar: uploadedImageUrl,
//             name: username,
//             country,
//             gender: genderValue,
//             maritalstatus: maritalValue,
//             dateofbirth: dob,
//             age: userAge,
//             about: "Available",
//             isverifiedprofile: true,
//           },
//         ]);

//       if (error) throw error;

//       alert("Signup successful!");
//     } catch (err) {
//       alert("Signup failed: " + err.message);
//     }
//   };

//   return (
//     <div className="signup-page">
//       <div className="signup-container">
//         <h1>Sign Up</h1>
//         <p>Create your account and start your journey</p>

//         <div className="profile-image-upload">
//           <label htmlFor="profile-upload">
//             {profileImage ? (
//               <img src={profileImage} alt="profile" className="profile-preview" />
//             ) : (
//               <div className="placeholder">👤</div>
//             )}
//           </label>
//           <input
//             id="profile-upload"
//             type="file"
//             accept="image/*"
//             onChange={pickImage}
//             style={{ display: "none" }}
//           />
//         </div>

//         <input
//           type="text"
//           placeholder="Name"
//           value={username}
//           onChange={(e) => setUsername(e.target.value)}
//         />
//         <input
//           type="email"
//           placeholder="Email"
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//         />
//         <input
//           type="password"
//           placeholder="Password"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//         />
//         <input
//           type="date"
//           value={dob}
//           onChange={(e) => setDob(e.target.value)}
//         />

//         <select value={genderValue} onChange={(e) => setGenderValue(e.target.value)}>
//           <option value="">Select Gender</option>
//           {genderItems.map((item) => (
//             <option key={item.value} value={item.value}>{item.label}</option>
//           ))}
//         </select>

//         <select value={maritalValue} onChange={(e) => setMaritalValue(e.target.value)}>
//           <option value="">Select Marital Status</option>
//           {maritalItems.map((item) => (
//             <option key={item.value} value={item.value}>{item.label}</option>
//           ))}
//         </select>

//         <input
//           type="text"
//           placeholder="Country"
//           value={country}
//           onChange={(e) => setCountry(e.target.value)}
//         />

//         <button onClick={onHandleSignup}>Sign Up</button>

//         <p>
//           Already a user? <a href="/login">Login</a>
//         </p>
//       </div>
//     </div>
//   );
// }



import React, { useState } from "react";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth } from "../../firebase/config";
import { supabase } from "../../firebase/supabaseClient";
import { useNavigate, Link } from "react-router-dom";
import './SignUp.css'; // New CSS file

export default function SignUp() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [dob, setDob] = useState("");
  const [genderValue, setGenderValue] = useState("");
  const [maritalValue, setMaritalValue] = useState("");
  const [country, setCountry] = useState("");
  const [profileImage, setProfileImage] = useState(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState("");

  const genderItems = [
    { label: "Male", value: "male" },
    { label: "Female", value: "female" },
    { label: "Other", value: "other" },
  ];

  const maritalItems = [
    { label: "Single", value: "single" },
    { label: "Married", value: "married" },
    { label: "Divorced", value: "divorced" },
  ];

  const pickImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setProfileImage(URL.createObjectURL(file));

    try {
      const filePath = `${Date.now()}_${file.name}`;
      const { error } = await supabase.storage
        .from("signUp_Images")
        .upload(filePath, file, { upsert: true });
      if (error) throw error;
      const { data } = supabase.storage.from("signUp_Images").getPublicUrl(filePath);
      setUploadedImageUrl(data.publicUrl);
    } catch (err) {
      console.error(err);
      alert("Image upload failed");
    }
  };

  const calculateAge = (birthDate) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age;
  };

  const onHandleSignup = async () => {
    if (!email || !password || !username || !dob || !genderValue || !maritalValue || !country || !uploadedImageUrl) {
      alert("Please fill all fields");
      return;
    }

    if (calculateAge(dob) < 18) {
      alert("You must be at least 18 years old.");
      return;
    }

    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(cred.user, { displayName: username });

      const { error } = await supabase.from("users").upsert([{
        id: cred.user.uid,
        email: cred.user.email,
        password,
        avatar: uploadedImageUrl,
        name: username,
        country,
        gender: genderValue,
        maritalstatus: maritalValue,
        dateofbirth: dob,
        age: calculateAge(dob),
        about: "Available",
        isverifiedprofile: true,
      }]);
      if (error) throw error;

      alert("Signup successful!");
      navigate("/");
    } catch (err) {
      alert("Signup failed: " + err.message);
    }
  };

  return (
    <div className="signup-page">
      <div className="safe-area">
        <div className="signup-container">
          <h1 className="title">Sign Up</h1>
          <p className="subtitle">Create your account and start your journey</p>

          <div className="profile-upload">
            <label htmlFor="profile-upload">
              {profileImage ? (
                <img src={profileImage} alt="profile" className="profile-preview" />
              ) : (
                <div className="placeholder">👤</div>
              )}
            </label>
            <input
              id="profile-upload"
              type="file"
              accept="image/*"
              onChange={pickImage}
              style={{ display: "none" }}
            />
          </div>

          <div className="form-fields">
            <input type="text" placeholder="Name" value={username} onChange={(e) => setUsername(e.target.value)} />
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <input type="date" value={dob} onChange={(e) => setDob(e.target.value)} />
            <select value={genderValue} onChange={(e) => setGenderValue(e.target.value)}>
              <option value="">Select Gender</option>
              {genderItems.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
            </select>
            <select value={maritalValue} onChange={(e) => setMaritalValue(e.target.value)}>
              <option value="">Select Marital Status</option>
              {maritalItems.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
            </select>
            <input type="text" placeholder="Country" value={country} onChange={(e) => setCountry(e.target.value)} />
          </div>

          <button onClick={onHandleSignup}>Sign Up</button>

          <p className="login-link">
            Already have an account? <Link to="/">Login</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
